require 'test_helper'

class RetweetTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
